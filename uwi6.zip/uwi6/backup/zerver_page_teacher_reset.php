<?php
include 'zerver_entrance.php';

session_start();

$email = $_SESSION["curr_email_user"];

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $sql = "UPDATE student_answers INNER JOIN created_questions ON student_answers.question_id = created_questions.question_id SET grades='0', checked='0', system_confidence='-1', re_eval='0' WHERE owner_teacher = '$email'";

  // Prepare statement
  $stmt = $conn->prepare($sql);

  // execute the query
  $stmt->execute();

  // echo a message to say the UPDATE succeeded
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>